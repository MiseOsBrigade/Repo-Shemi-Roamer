const canvas = document.querySelector('#sea');
const status = document.querySelector('#status');

if (!(canvas instanceof HTMLCanvasElement) || !(status instanceof HTMLElement)) {
  throw new Error('Open Sea document is missing required elements.');
}

const resize = () => {
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  const width = Math.max(1, Math.floor(canvas.clientWidth * ratio));
  const height = Math.max(1, Math.floor(canvas.clientHeight * ratio));
  if (canvas.width !== width || canvas.height !== height) {
    canvas.width = width;
    canvas.height = height;
  }
};

async function startWebGpu() {
  if (!navigator.gpu) return false;
  const adapter = await navigator.gpu.requestAdapter();
  if (!adapter) return false;
  const device = await adapter.requestDevice();
  const context = canvas.getContext('webgpu');
  if (!context) return false;

  const format = navigator.gpu.getPreferredCanvasFormat();
  context.configure({ device, format, alphaMode: 'opaque' });

  const shader = device.createShaderModule({ code: `
    struct Uniforms { resolution: vec2f, time: f32, pad: f32 }
    @group(0) @binding(0) var<uniform> uniforms: Uniforms;

    @vertex fn vertexMain(@builtin(vertex_index) index: u32) -> @builtin(position) vec4f {
      let points = array<vec2f, 3>(vec2f(-1.0, -1.0), vec2f(3.0, -1.0), vec2f(-1.0, 3.0));
      return vec4f(points[index], 0.0, 1.0);
    }

    fn wave(p: vec2f, direction: vec2f, frequency: f32, speed: f32) -> f32 {
      return sin(dot(p, normalize(direction)) * frequency + uniforms.time * speed);
    }

    @fragment fn fragmentMain(@builtin(position) position: vec4f) -> @location(0) vec4f {
      let uv = position.xy / uniforms.resolution;
      let aspect = uniforms.resolution.x / uniforms.resolution.y;
      let p = vec2f((uv.x - 0.5) * aspect, uv.y - 0.5);
      let horizon = smoothstep(-0.35, 0.48, p.y);
      let swell = wave(p, vec2f(1.0, 0.28), 14.0, 1.1)
                + 0.55 * wave(p, vec2f(-0.45, 1.0), 23.0, -1.7)
                + 0.25 * wave(p, vec2f(0.7, 1.0), 47.0, 2.2);
      let foam = pow(max(0.0, swell * 0.22 + 0.20 - p.y), 5.0);
      let deep = vec3f(0.015, 0.10, 0.18);
      let surface = vec3f(0.02, 0.34, 0.48);
      let sky = vec3f(0.12, 0.50, 0.68);
      var color = mix(deep, surface, 0.46 + 0.32 * swell);
      color = mix(color, sky, horizon * 0.58);
      color += vec3f(0.44, 0.92, 1.0) * foam;
      color *= 0.82 + 0.18 * (1.0 - length(p) * 0.55);
      return vec4f(color, 1.0);
    }
  ` });

  const pipeline = device.createRenderPipeline({
    layout: 'auto',
    vertex: { module: shader, entryPoint: 'vertexMain' },
    fragment: { module: shader, entryPoint: 'fragmentMain', targets: [{ format }] },
    primitive: { topology: 'triangle-list' }
  });

  const buffer = device.createBuffer({
    size: 16,
    usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
  });
  const bindGroup = device.createBindGroup({
    layout: pipeline.getBindGroupLayout(0),
    entries: [{ binding: 0, resource: { buffer } }]
  });
  const started = performance.now();

  const frame = (now) => {
    resize();
    device.queue.writeBuffer(buffer, 0, new Float32Array([
      canvas.width,
      canvas.height,
      (now - started) / 1000,
      0
    ]));
    const encoder = device.createCommandEncoder();
    const pass = encoder.beginRenderPass({
      colorAttachments: [{
        view: context.getCurrentTexture().createView(),
        clearValue: { r: 0.01, g: 0.05, b: 0.09, a: 1 },
        loadOp: 'clear',
        storeOp: 'store'
      }]
    });
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.draw(3);
    pass.end();
    device.queue.submit([encoder.finish()]);
    requestAnimationFrame(frame);
  };

  status.textContent = 'WebGPU renderer active · resize the window to reshape the sea.';
  requestAnimationFrame(frame);
  return true;
}

function startCanvasFallback() {
  const context = canvas.getContext('2d');
  if (!context) throw new Error('No compatible canvas renderer is available.');
  const started = performance.now();
  const frame = (now) => {
    resize();
    const time = (now - started) / 1000;
    const gradient = context.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, '#167b9f');
    gradient.addColorStop(0.45, '#07516f');
    gradient.addColorStop(1, '#041625');
    context.fillStyle = gradient;
    context.fillRect(0, 0, canvas.width, canvas.height);
    for (let band = 0; band < 18; band += 1) {
      const y = canvas.height * (0.32 + band / 25);
      context.beginPath();
      for (let x = 0; x <= canvas.width; x += 8) {
        const wave = Math.sin(x * 0.016 + time * (0.7 + band * 0.03)) * (4 + band * 0.7);
        if (x === 0) context.moveTo(x, y + wave);
        else context.lineTo(x, y + wave);
      }
      context.strokeStyle = `rgba(139, 233, 253, ${0.08 + band * 0.012})`;
      context.lineWidth = 1 + band * 0.08;
      context.stroke();
    }
    requestAnimationFrame(frame);
  };
  status.textContent = 'Canvas fallback active · WebGPU was unavailable.';
  requestAnimationFrame(frame);
}

resize();
startWebGpu().then((started) => {
  if (!started) startCanvasFallback();
}).catch((error) => {
  console.warn('WebGPU initialization failed; using Canvas fallback.', error);
  startCanvasFallback();
});
