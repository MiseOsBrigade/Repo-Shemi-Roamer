# Changelog

## 1.0.0 — 2026-08-04

- Initial LinkForge suite release.
